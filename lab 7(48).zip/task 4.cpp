#include<iostream>
using namespace std;
class stack{
	private:
		void swap(int & a,int & b){
			int c;
			c=a;
			a=b;
			b=c;
		}
	public:
	int size;
	int arr[10],top;
	
		stack(){
			top=-1;
			size=10;
			for(int i=0;i<size;i++){
				arr[i]=0;
			}
			}
	
	void push(int value){
			if (top==size){
				cout<<"ERROR!!!!! OVERFLOW: ";
			}
			else {
				top++;
				arr[top]=value;
			}
		}
		int pop(){
			if(top==-1){
				cout<<"underflow ERORR!!!!!!!";
			}else
			arr[top]=0;
			top--;
		}
	void peek(){
			cout<<"peak:"<<arr[top];
		}
	void is_empty(){
			if(top==-1){
				cout<<"EMPTY:";
			}else 
			cout<<"NOT EMPTY: ";
		}
	
	
	void split(int position,stack & first_h){
		if (position >=top ){
			cout<<"NOT SPLITABLE ";
		}
		else{
			for(int i=0;i<position;i++){
				first_h.top++;
				first_h.arr[first_h.top]=arr[i];
			}
			for(int i=position-1;i<top;i++){
				arr[i-position+1]=arr[i+1];
			}
			top-=position;
		}
	}
	void display(){
			for(int i=0;i<=top;i++){
			cout<<arr[i]<<" ";
			}
		}
	};
int main(){
	stack st1,st;
	for(int i=252;i<260;i++){
	st1.push(i);
} 
    st1.display();
	cout<<endl;
	
	cout<<endl;
	st1.split(4,st);
	
	
	cout<<"FIRST PART:"<<endl;
	st.display();
	cout<<endl;
	cout<<"SEcond PART:"<<endl;
	st1.display();
}
