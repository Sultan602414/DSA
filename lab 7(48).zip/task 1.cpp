#include<iostream>
using namespace std;
class stack{
	public:
	int size;
	int arr[5],top;
	
		stack(){
			top=-1;
			size=5;
			for(int i=0;i<size;i++){
				arr[i]=0;
			}
	void push(int value);
	int pop();
	void peek();
	void is_empty();

		}
		push(int value){
			if (top==size){
				cout<<"ERROR!!!!! OVERFLOW: ";
			}
			else {
				top++;
				arr[top]=value;
			}
		}
		pop(){
			if(top==-1){
				cout<<"underflow ERORR!!!!!!!";
			}else
			arr[top]=0;
			top--;
		}
		peek(){
			cout<<"peak:"<<arr[top];
		}
		is_empty(){
			if(top==-1){
				cout<<"EMPTY:";
			}else 
			cout<<"NOT EMPTY: ";
		}
			void display(){
			for(int i=0;i<=top;i++){
			cout<<arr[i]<<" ";
			}
		}		
};
int main(){
	stack st1;
	for(int i=252;i<257;i++){
	st1.push(i);
} 
	st1.peek();
	st1.pop();
	cout<<endl;
	st1.peek();
	cout<<endl;
	st1.display();

}
