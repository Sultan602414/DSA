#include<iostream>
using namespace std;
class stack{
	private:
		void swap(int & a,int & b){
			int c;
			c=a;
			a=b;
			b=c;
		}
	public:
	int size;
	int arr[5],top;
	
		stack(){
			top=-1;
			size=5;
			for(int i=0;i<size;i++){
				arr[i]=0;
			}
	void push(int value);
	int pop();
	void peek();
	void is_empty();

		}
		push(int value){
			if (top==size){
				cout<<"ERROR!!!!! OVERFLOW: ";
			}
			else {
				top++;
				arr[top]=value;
			}
		}
		pop(){
			if(top==-1){
				cout<<"underflow ERORR!!!!!!!";
			}else
			arr[top]=0;
			top--;
		}
		peek(){
			cout<<"peak:"<<arr[top];
		}
		is_empty(){
			if(top==-1){
				cout<<"EMPTY:";
			}else 
			cout<<"NOT EMPTY: ";
		}
			void display(){
			for(int i=0;i<=top;i++){
			cout<<arr[i]<<" ";
			}
		}
		void reverse(){
			if(top>=1){
			
			int count=0;
			int rev_count=top;

			
			while(count<=top/2){
				swap(arr[count],arr[rev_count]);
				
				count++;
				rev_count--;
			}
		}else 
		cout<<"NOT REVERSiBLE: ";	
		}		
};
int main(){
	stack st1;
	for(int i=252;i<257;i++){
	st1.push(i);
} st1.display();
cout<<endl;
	
	cout<<endl;
//	st1.pop();
//	st1.pop();
	st1.reverse();
	st1.display();

}
