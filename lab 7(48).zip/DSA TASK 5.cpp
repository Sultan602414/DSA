#include <iostream>
using namespace std;

const int MAX_SIZE = 10;

// Structure for a simple stack
struct Stack {
    int arr[MAX_SIZE];
    int top;

    // Constructor
    Stack() {
        top = -1;
    }

    // Function to check if the stack is empty
    bool isEmpty() {
        return top == -1;
    }

    // Function to push an element onto the stack
    void push(int value) {
        if (top == MAX_SIZE - 1) {
            cout << "Stack overflow! Cannot push more elements." << endl;
            return;
        }
        arr[++top] = value;
    }

    // Function to pop an element from the stack
    void pop() {
        if (isEmpty()) {
            cout << "Stack underflow! Cannot pop from an empty stack." << endl;
            return;
        }
        top--;
    }

    // Function to get the top element of the stack
    int topElement() {
        if (isEmpty()) {
            cout << "The stack is empty." << endl;
            return -1; // Return a sentinel value indicating an empty stack
        }
        return arr[top];
    }
};

// Function to merge two sorted stacks into a single sorted stack
void mergeSortedStacks(Stack& stack1, Stack& stack2, Stack& mergedStack) {
    // Merge stacks while they are not both empty
    while (!stack1.isEmpty() || !stack2.isEmpty()) {
        int value;

        // If one stack is empty, push the remaining elements from the other stack
        if (stack1.isEmpty()) {
            value = stack2.topElement();
            stack2.pop();
        } else if (stack2.isEmpty()) {
            value = stack1.topElement();
            stack1.pop();
        } else {
            // Compare the top elements of both stacks and push the smaller one
            if (stack1.topElement() <= stack2.topElement()) {
                value = stack1.topElement();
                stack1.pop();
            } else {
                value = stack2.topElement();
                stack2.pop();
            }
        }

        // Push the value onto the merged stack
        mergedStack.push(value);
    }
}

int main() {
    // Create two sorted stacks
    Stack stack1, stack2;

    stack1.push(10);
    stack1.push(20);
    stack1.push(30);
    stack1.push(40);
    stack1.push(50);

    stack2.push(60);
    stack2.push(70);
    stack2.push(80);
    stack2.push(90);
    stack2.push(100);

    // Create a stack to store the merged result
    Stack mergedStack;

    // Merge the two sorted stacks
    mergeSortedStacks(stack2, stack1, mergedStack);

    // Display the merged stack
    cout << "Merged stack: (";
    while (!mergedStack.isEmpty()) {
        cout << mergedStack.topElement();
        mergedStack.pop();
        if (!mergedStack.isEmpty()) {
            cout << ", ";
        }
    }
    cout << ")" << endl;

    return 0;
}
