#include<iostream>
using namespace std;
class node{
	
	public:
		node *left;
		node *right;
		int data;
		node(int value){
			data=value;
			left=right=NULL;
			
		}
		
};
class tree{
	public:
	node *root;
	tree(){
		root=NULL;
	}
	void insert(int value){
		node *newnode= new node(value);
		if(root==NULL){
			root=newnode;
		}
		else{
			node *temp1=root;
			node *temp2=root;
			while(true){
			temp2=temp1;
			if(value<temp1->data){
				temp1=temp1->left;
				if(temp1==NULL){
					temp2->left=newnode;
//					cout<<temp1->data<<" ";
					break;
				}
			}
				else {
				if (value>temp1->data){
				temp1=temp1->right;
				if(temp1==NULL){
					temp2->right=newnode;
//					cout<<temp1->data<<" ";
					break;
				}
			}
}
		}
		}
		 
	}
	
	void display(node *temp){
		cout<<temp->data<<" ";
		if(temp->left!=NULL){
			
			display(temp->left);
			
		}
		if(temp->right!=NULL){
		
		display(temp->right);
		}
	}
	
};
int main(){
	tree t1;
	t1.insert(10);
	t1.insert(20);
	t1.insert(30);
	t1.insert(40); 
	t1.insert(50);
	
	t1.display(t1.root);
	
}
