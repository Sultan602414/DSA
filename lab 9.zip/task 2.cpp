#include<iostream>
using namespace std;
class node{
	
	public:
		node *left;
		node *right;
		int data;
		node(int value){
			data=value;
			left=right=NULL;
			
		}
		
};
class tree{
	public:
	node *root;
	tree(){
		root=NULL;
	}
	void insert(int value){
		node *newnode= new node(value);
		if(root==NULL){
			root=newnode;
		}
		else{
			node *temp1=root;
			node *temp2=root;
			while(true){
			temp2=temp1;
			if(value<temp1->data){
				temp1=temp1->left;
				if(temp1==NULL){
					temp2->left=newnode;
//					cout<<temp1->data<<" ";
					break;
				}
			}
				else {
				if (value>temp1->data){
				temp1=temp1->right;
				if(temp1==NULL){
					temp2->right=newnode;
//					cout<<temp1->data<<" ";
					break;
				}
			}
}
		}
		}
		 
	}
	
	void display(node *temp){
		cout<<temp->data<<" ";
		if(temp->left!=NULL){
			
			display(temp->left);
			
		}
		if(temp->right!=NULL){
		
		display(temp->right);
		}
	}
	
	void find(int value ){
		node *temp=root;
		if(temp->data=value){
			cout<< "   \n   FOUNDED    ";
		
		}
	else{
	
		if(temp->left!=NULL){
			
			find(temp->data);
			
		}
		if(temp->right!=NULL){
		
		find(temp->data);
		}
	}
}
};
int main(){
	tree t1;
	t1.insert(8);
	t1.insert(3);
	t1.insert(10);
	t1.insert(1); 
	t1.insert(6);
	t1.insert(14);
	t1.insert(4);
	t1.insert(7);
	t1.insert(13);
	t1.display(t1.root);
	t1.find(7);
	
}
