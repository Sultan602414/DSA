#include<iostream>
using namespace std;

int  rec_sum (int n){
	if (n==1){
		return 1;
		
	}
	else {
		return n * rec_sum(n-1);
	}
	
}
int main(){
	int num,sum;
	cout<<"ENTER THE NUMBER: ";
	cin >> num;
	if(num>=1){
	sum= rec_sum(num);
cout<<"THE SUM IS "<< sum;	
}
else 
	cout<<"ENTER THE  correct NUMBER ";
}
