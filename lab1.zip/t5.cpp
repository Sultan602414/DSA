#include <iostream>
using namespace std;


int integer(int & num)
{
	cout<<"Please enter your integer: ";
	cin>>num;
		if(num<1)
	{
		integer(num);
	}
	else
	{
	return num;
    }
}
   
 int recursive_fxn(int num, int num1, int num2)
{
	int result;
	if (num==1)
	{
		return 1;
		 } 	
    else 
    {
    	result=num1+num2;
    	cout<<" "<<num1;
    	num1=num2;
    	num2=result;
    	return num+recursive_fxn(num-1, num1, num2);
	}				
}
int main()
{
	int num, num1=1, num2=1;
	integer(num);
	cout<<0;
	recursive_fxn(num, num1, num2);
	  
}