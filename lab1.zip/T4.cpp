#include<iostream>
using namespace std;

int  rec_sum (int n , int & count ){
	if (n==0){
		return 1;
		
	}
	else {
		n = n / 10;
		count++;
		rec_sum(n,count);
	}
	
}
int main(){
	int num,sum,count = 0;
	cout<<"ENTER THE NUMBER: ";
	cin >> num;
	if(num>=1){
	 rec_sum(num, count);
	 cout<< "THE DIGIT IS " <<count;

}
else 
	cout<<"ENTER THE  correct NUMBER ";
}
