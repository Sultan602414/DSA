#include<iostream>
using namespace std;
 
 int rec_pow(int n, int x){
 	if(x==0){
 		return 1;
	 }
	 else {
	 	return n*rec_pow(n,x-1);
	 }
 	
 }
 
 int main (){
 	
 	int num , pow, sum;
 	cout << "ENTER THE NUMBER ";
 	cin>> num;
 	cout << "ENTER THE POWER  ";
 	cin>> pow;
 	
 	if (num>=1){
 		sum= rec_pow(num,pow);
 		cout<<"THE RESuLT IS : "<<sum;
	 }
	 else{
	 	cout<<"   Enter the number and power corectly   ";
	 }
 }
 
 