#include<iostream>
using namespace std;
class node{
	public:
	int data;	
	node *next;
	
	node(int value){
		data=value;
		next=NULL;
	}
};
class linklist{
	private:
		node *head;
		public:
		linklist(){
			head=NULL;
		}
		
	void insert_at_end(int value){
		
		node *newnode= new node(value);
		if (head==NULL){
			head=newnode;
		}
		else{
			node *temp=head;
			while(temp->next != NULL){
			temp=temp->next;
		}
			temp->next=newnode;
		}
	}
	
		void insert_at_start(int value){
		cout<<"ENTER THE NUMBER TO ADD in start "<<endl;
		cin>>value;
		node *newnode= new node(value);
		if (head==NULL){
			head=newnode;
		}
		else{
			newnode->next=head;
			node *temp=head;
			head=newnode;
			
			while(temp->next != NULL){
			temp=temp->next;
		}
		}
	}
	
		void insert_end_user(int value){
		cout<<"ENTER THE NUMBER TO ADD IN A NEW NODE"<<endl;
		cin>>value;
		node *newnode= new node(value);
		if (head==NULL){
			head=newnode;
		}
		else{
			node *temp=head;
			while(temp->next != NULL){
			temp=temp->next;
		}
			temp->next=newnode;
		}
	}
	
	
	
		
void insert_anywhere(int value,int position)
{
	cout<<"ENTER THE VALUE: "<<endl;
	cin>>value;
	cout<<"ENTER THE POSITION: "<<endl;
	cin>>position;
	node* newNode = new node(value);
        if (position == 0)
        {
            newNode->next = head;
            head = newNode;
        }
        else
        {
            node* current = head;
            node* previous = nullptr;
            for (int i = 1; i < position && current != nullptr; i++)
            {
                previous = current;
                current = current->next;
            }
            if (current == nullptr)
            {
              cout << "\nPosition out of bounds." <<endl;
              cout<<"\nYour previous linkelist is sustained";
            }
            else
            {
                newNode->next = current;
                previous->next = newNode;
            }
        }
}
	
	
	
	
	


	void display(){
		node*temp=head;
				while(temp!= NULL){
					cout<<temp->data<<",";
					temp=temp->next;
	}

	

}};

int main(){
	int x,y;
	linklist list_1;
	list_1.insert_at_end(6);
	list_1.insert_at_end(5);
	list_1.insert_at_end(4);
	list_1.insert_at_end(3);
	list_1.display();
	cout<<endl;
	list_1.insert_end_user(x);
	
	cout<<endl;
	list_1.display();
	
	
	cout<<endl;
	list_1.insert_at_start(x);
	
	
	
	cout<<endl;
	list_1.display();
	cout<<endl;
	list_1.insert_anywhere(x,y);
	cout<<endl;
	list_1.display();
}