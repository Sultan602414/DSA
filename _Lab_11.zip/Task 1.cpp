#include <iostream>

using namespace std;

class MaxHeap {
private:
    int* heap;
    int capacity;
    int size;

    void resize() {
        capacity *= 2;
        int* newHeap = new int[capacity];
        for (int i = 0; i < size; ++i) {
            newHeap[i] = heap[i];
        }
        delete[] heap;
        heap = newHeap;
    }

    void heapifyUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (heap[index] > heap[parentIndex]) {
                swap(heap[index], heap[parentIndex]);
                index = parentIndex;
            } else {
                break;
            }
        }
    }

    void heapifyDown(int index) {
        int leftChild = 2 * index + 1;
        int rightChild = 2 * index + 2;
        int largest = index;

        if (leftChild < size && heap[leftChild] > heap[largest]) {
            largest = leftChild;
        }

        if (rightChild < size && heap[rightChild] > heap[largest]) {
            largest = rightChild;
        }

        if (largest != index) {
            swap(heap[index], heap[largest]);
            heapifyDown(largest);
        }
    }

public:
    MaxHeap(){
        capacity=10;
        size=0;
        heap = new int[capacity];
    }

    void insert(int value) {
        if (size == capacity) {
            resize();
        }

        heap[size++] = value;
        heapifyUp(size - 1);
    }

    int deleteMax() {
        if (size == 0) {
            cout << "Heap is empty. Cannot delete max element.\n";
            return -1;
        }

        int maxValue = heap[0];
        heap[0] = heap[--size];
        heapifyDown(0);

        return maxValue;
    }

    void display() {
        for (int i = 0; i < size; ++i) {
            cout << heap[i] << " ";
        }
        cout << "\n";
    }
};

int main() {
    MaxHeap maxHeap;

    maxHeap.insert(30);
    maxHeap.insert(20);
    maxHeap.insert(40);
    maxHeap.insert(10);
    maxHeap.insert(25);
    maxHeap.insert(35);
    maxHeap.insert(50);

    cout << "Max Heap after insertion: ";
    maxHeap.display();

    int deletedValue = maxHeap.deleteMax();
    if (deletedValue != -1) {
        cout << "Deleted max element: " << deletedValue << "\n";
        cout << "Max Heap after deletion: ";
        maxHeap.display();
    }

    return 0;
}
