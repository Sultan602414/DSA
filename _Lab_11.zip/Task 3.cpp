#include <iostream>
using namespace std;

class MaxHeap {
private:
    int *heapArray;
    int capacity;
    int heapSize;


    int getParentIndex(int childIndex) {
        return (childIndex - 1) / 2;
    }


    void heapify(int index) {
        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < heapSize && heapArray[left] > heapArray[largest]) {
            largest = left;
        }

        if (right < heapSize && heapArray[right] > heapArray[largest]) {
            largest = right;
        }

        if (largest != index) {
            swap(heapArray[index], heapArray[largest]);
            heapify(largest);
        }
    }

public:
    MaxHeap(int cap) {
        capacity = cap;
        heapArray = new int[capacity];
        heapSize = 0;
    }


    void insert(int val) {
        if (heapSize == capacity) {
            cout << "Heap is full. Cannot insert." << endl;
            return;
        }

        int i = heapSize;
        heapArray[i] = val;
        heapSize++;

        while (i != 0 && heapArray[getParentIndex(i)] < heapArray[i]) {
            swap(heapArray[i], heapArray[getParentIndex(i)]);
            i = getParentIndex(i);
        }
    }


    bool isEmpty() {
        return heapSize == 0;
    }


    void displayHeap() {
        cout << "Max Heap: ";
        for (int i = 0; i < heapSize; ++i) {
            cout << heapArray[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MaxHeap maxHeap(10);


    maxHeap.insert(10);
    maxHeap.insert(5);
    maxHeap.insert(3);
    maxHeap.insert(2);
    maxHeap.insert(4);

    maxHeap.displayHeap();

    maxHeap.insert(15);
    maxHeap.displayHeap();


    return 0;
}
