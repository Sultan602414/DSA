#include <iostream>

using namespace std;

class MinHeap {
private:
    int* heap;
    int capacity;
    int size;

    void resize() {
        capacity *= 2;
        int* newHeap = new int[capacity];
        for (int i = 0; i < size; ++i) {
            newHeap[i] = heap[i];
        }
        delete[] heap;
        heap = newHeap;
    }

    void heapifyUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (heap[index] < heap[parentIndex]) {
                swap(heap[index], heap[parentIndex]);
                index = parentIndex;
            } else {
                break;
            }
        }
    }

    void heapifyDown(int index) {
        int leftChild = 2 * index + 1;
        int rightChild = 2 * index + 2;
        int smallest = index;

        if (leftChild < size && heap[leftChild] < heap[smallest]) {
            smallest = leftChild;
        }

        if (rightChild < size && heap[rightChild] < heap[smallest]) {
            smallest = rightChild;
        }

        if (smallest != index) {
            swap(heap[index], heap[smallest]);
            heapifyDown(smallest);
        }
    }

public:
    MinHeap(){
        capacity=10;
        size=0;
        heap = new int[capacity];
    }

    void insert(int value) {
        if (size == capacity) {
            resize();
        }

        heap[size++] = value;
        heapifyUp(size - 1);
    }

    int deleteMin() {
        if (size == 0) {
            cout << "Heap is empty. Cannot delete min element.\n";
            return -1;
        }

        int minValue = heap[0];
        heap[0] = heap[--size];
        heapifyDown(0);

        return minValue;
    }

    void display() {
        for (int i = 0; i < size; ++i) {
            cout << heap[i] << " ";
        }
        cout << "\n";
    }
};

int main() {
    MinHeap minHeap;

    minHeap.insert(30);
    minHeap.insert(20);
    minHeap.insert(40);
    minHeap.insert(10);
    minHeap.insert(25);
    minHeap.insert(35);
    minHeap.insert(50);

    cout << "Min Heap after insertion: ";
    minHeap.display();

    int deletedValue = minHeap.deleteMin();
    if (deletedValue != -1) {
        cout << "Deleted min element: " << deletedValue << "\n";
        cout << "Min Heap after deletion: ";
        minHeap.display();
    }

    return 0;
}
