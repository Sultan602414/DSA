#include<iostream>
using namespace std;
class que{
	private:
		int arr[10];
		int size;
		int rare;
		int front;
	public:	
		que(){
			size=10;
			rare=front=-1;
			arr[size];
			
			for(int i=0;i<size;i++){
				arr[i]=0;
			}
		}
		void enque(int value){
			rare++;
			arr[rare]=value;
		}
		void deque(){
			front++;
			arr[front]=0;
		}
		void isempty(){
			if(rare==front){
				cout<<"THE QUEUE IS EMPTY"<<endl;
			}
			else
			cout<<"THE QUEUE IS not EMPTY"<<endl;
		}
		void peek(){
			cout<<"your front most entry is "<<arr[front]<<endl;
		}
		void change(){
			cout<<" \n IN a queue we can not change the values at random in any other position \n unless it is at the start or at the end"<<endl;
		}
		void isfull(){
			if(rare==size){
			
			cout<<"your queue is full"<<endl;
			}
			else {
					cout<<"your queue is not yet  full"<<endl;
			}
		}
		void print(){
			for(int i=front+1;i<=rare;i++){
		cout<<arr[i]<<" ";
	}
		}
			
		
};

int main(){
	que q1;
	for(int i=10;i<=50;i+=10){
		q1.enque(i);
	}
	q1.print();
	cout<<endl;
	
	q1.enque(54);
//		q1.print();
		cout<<endl;
	q1.deque();
//		q1.print();
		cout<<endl;
	q1.deque();
//		q1.print();
		cout<<endl;
	q1.change();
//		q1.print();
		cout<<endl;
	q1.enque(80);
	
	cout<<endl;
	q1.print();
	
}
