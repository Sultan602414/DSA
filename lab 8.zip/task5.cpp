#include<iostream>
using namespace std;

class Queue
{
private:
	int arr[10];
	int size, rear, front;
public:
	Queue()
	{
		size = 10;
		arr[size];
		rear = -1;
		front = -1;
		for (int i=0; i<10; i++)
		{
			arr[i]=0;
		}
	}

	void enqueue(int value)
	{
		rear++;
		arr[rear] = value;
	}

	void dequeue()
	{
		front++;
		arr[front] = 0;
	}

	void peek()
	{
		cout<<"Your front most entry is: "<<arr[front]<<endl;
	}

	void change(int a, int b)
	{
		cout<<"You can not change value directly at any position in Queue!\n";
	}

	void empty()
	{
		if (front == rear)
		{
			cout<<"Your Queue is empty!\n";
		}
		else
		{
			cout<<"Your Queue is not empty!\n";
		}
	}

	void full()
	{
		if (rear == size)
		{
			cout<<"Your Queue is full!\n";
		}
		else
		{
			cout<<"Your Queue is not full\n";
		}
	}

	void print()
	{
		for (int i=front+1; i<=rear; i++)
		{
			cout<<arr[i]<<" ";
		}
		cout<<endl;
	}

	void split(Queue &obj)
	{
		for(int i=front+1; i<=rear/2; i++)
		{
			obj.arr[i] = arr[i];
			obj.rear++;
			front++;
		}
	}

	void merg(Queue &obj)
	{
		for(int i=front+1; i<=rear; i++)
		{
			obj.arr[i] = arr[i];
			obj.rear++;
			front++;
		}
	}
};
int main()
{
Queue que, que2;
for(int i=15; i<=90; i=i+15)
{
que.enqueue(i);
}
que.split(que2);
cout<<"First queue: ";
que2.print();
cout<<"Second queue: ";
que.print();
que.merg(que2);
cout<<"First queue merge in second: ";
que2.print();
//que2.dequeue();
//que2.print();
}
