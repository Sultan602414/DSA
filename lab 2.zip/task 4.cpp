#include<iostream>
using namespace std;
int main(){
int arr[3][4]={{10,20,30,40},{50,60,70,80},{90,100,110,120}};

arr[1][3]={ };
for(int j=0;j<3;j++){

for(int i=0;i<4;i++){
	
	cout<<arr[j][i]<<" ";
	
}
cout<<endl;

}

}