#include<iostream>
using namespace std;
int main()
{
int arr[6]={5, 12, 24, 36, 48, 60};
int i;
for(i=0; i<6;i++)
{
cout<<arr[i]<<" ";
}
return 0;
}
