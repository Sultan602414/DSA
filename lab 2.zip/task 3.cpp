#include<iostream>
using namespace std;
int main()
{
int arr[7]={10, 20, 30, 40, 50, 60, 70};
int pos=4;
int i;
cout<<"Original Array: ";
for(i=0; i<6; i++)
{
cout<<arr[i]<<" ";
}
cout<<endl;
for(i=pos; i<7; i++)
{
arr[i]=arr[i+1];
}
cout<<"New Array: ";
for(i=0; i<6; i++)
{
cout<<arr[i]<<" ";
}
}