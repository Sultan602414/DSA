#include<iostream>
using namespace std;
int main()
{
int arr[10]={12, 45, 78, 34, 56, 90, 23, 67};
int pos=3;
int num=50;
int i;
for(i=8; i>=pos; i--)
{
arr[i+1]=arr[i];
}
arr[pos]=num;
cout<<"New Array: ";

for(i=0; i<9;i++)
{
cout<<arr[i]<<" ";
}

return 0;
}
